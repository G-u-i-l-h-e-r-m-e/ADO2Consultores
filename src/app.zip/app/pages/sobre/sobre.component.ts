import { Component } from '@angular/core';

@Component({
  selector: 'app-sobre',
  standalone: true,
  template: `
    <h2>Sobre</h2>
    <p>Aplicação Angular para gerenciamento de consultores.</p>
  `
})
export class SobreComponent {}
