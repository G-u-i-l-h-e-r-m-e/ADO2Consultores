export interface Consultor {
  id: number;
  nome: string;
  email: string;
  telefone?: string;
}
